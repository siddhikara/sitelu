library(shiny)

#runApp("D:/xampp/htdocs/telaah/R/app.R", port = 3661, host = getOption("shiny.host","10.2.3.42"))

#runApp("C:/xampp/htdocs/telaah/R/app.R", port = 3661, host = getOption("shiny.host","192.168.0.118"))
#runApp("C:/xampp/htdocs/telaah/R/app_ujicoba.R", port = 3661, host = getOption("shiny.host","172.32.10.107"))

#runApp("E:/BPS/Biro Keuangan Bagian Akuntansi/2. develop/R/app_ujicoba.R", port = 3661, host = getOption("shiny.host","10.2.3.151"))
runApp("//127.0.0.1/xampp/htdocs/telaah/R/new_app.R", port = 7905, host = getOption("shiny.host","10.2.3.42"))